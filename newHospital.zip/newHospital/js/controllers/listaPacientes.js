"use strict";
define(['angular','jquery',],function (angular,$) {

angular.module("controllers")
	.controller('listaPacientesCtrl', ['$scope','$rootScope', function($scope,$rootScope) {
  		getList();
  		
  		$rootScope.$watch('pacientesList',function(newValue, oldValue){
  			if(newValue!=oldValue)
  				getList();
  		})
      $scope.deletePacient=function(id){
        var parseObj=Parse.Object.extend("pacientes");
        var paciente= new Parse.Query(parseObj)
            paciente.equalTo("objectId",id)
            paciente.destroy({
              success:function(p){
                alert("se ha eliminado al paciente del registro")
              },
              error: function(myObject, error) {
                // The delete failed.
                // error is a Parse.Error with an error code and message.
              }
            })

      }
  		function getList(){
  			$scope.list=$rootScope.pacientesList;
  		}

	}]);
})