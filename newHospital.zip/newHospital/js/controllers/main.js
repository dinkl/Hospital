angular.module("controllers",[])

define(['./loginCtrl','./home','./hoja','./usuarioCtrl','./listaPacientes','./pacienteInfo', 
	'./reportesCtrl','./causesCtrl','./causeDetail'], function(){
	
});