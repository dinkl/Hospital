"use strict";
define(['angular','jquery',],function (angular,$) {

angular.module("controllers")
	.controller('pacienteCtrl', ['$scope','$routeParams', function($scope,$routeParams) {
  		$scope.edit=false
        var currentPacient;
        if($routeParams.id){
            getUserInfo($routeParams.id)
        }
        
        function getUserInfo(id){
            $scope.edit=true
            var pObject = Parse.Object.extend("pacientes");
            var paciente= new Parse.Query(pObject)
                paciente.equalTo("objectId",id)
                //query.select("NOMBRE","EXPEDIENTE")
                //query.ascending("NOMBRE");
                paciente.first({
                    success:function(data){
                        console.log(data)
                        if(data!=null){
                            currentPacient=data;
                            $scope.expediente=data.get("EXPEDIENTE")
                            $scope.nombre=data.get("NOMBRE")
                            $scope.nacimiento=data.get("NACIMIENTO")
                            $scope.sexo=data.get("SEXO")
                            $scope.oportunidades=data.get("OPORTUNIDADES")
                            $scope.popular=data.get("Numero")
                            $scope.migrante=data.get("MIGRANTE")
                            $scope.indigena=data.get("INDIGENA")
                            $scope.discapacidad=data.get("DISCAPACIDAD")
                            var edad=$scope.nacimiento.split("/")
                            $scope.edad=calculateAge(edad[1],edad[0],edad[2])
                            $scope.$apply();

                        }
                    },error:function(error){

                    }
                })
        }

        function calculateAge(birthMonth, birthDay, birthYear)
                {
                  var todayDate = new Date();
                  var todayYear = todayDate.getFullYear();
                  var todayMonth = todayDate.getMonth();
                  var todayDay = todayDate.getDate();
                  var age = todayYear - birthYear; 

                  if (todayMonth < birthMonth - 1)
                  {
                    age--;
                  }

                  if (birthMonth - 1 == todayMonth && todayDay < birthDay)
                  {
                    age--;
                  }
                  return age;
                }

        var guid = (function() {
              function s4() {
                return Math.floor((1 + Math.random()) * 0x10000)
                           .toString(16)
                           .substring(1);
              }
              return function() {
                return s4() + s4() + '-' + s4();
              };
            })();
        

        $scope.savePacient=function(invalid){
            if(invalid)
                $(".ng-invalid").addClass("ng-dirty")
            else{
                //Select object to update or inser registry
                if(currentPacient==null){
                    var Pacientes = Parse.Object.extend("pacientes");
                    currentPacient = new Pacientes();
                    currentPacient.set("ID", guid());
                }
                currentPacient.set("EXPEDIENTE",$scope.expediente)
                currentPacient.set("NOMBRE",$scope.nombre)
                currentPacient.set("NACIMIENTO",$scope.nacimiento)
                currentPacient.set("SEXO",$scope.sexo)
                currentPacient.set("OPORTUNIDADES",$scope.oportunidades)
                currentPacient.set("Numero",$scope.popular)
                currentPacient.set("MIGRANTE",$scope.migrante)
                currentPacient.set("INDIGENA",$scope.indigena)
                currentPacient.set("DISCAPACIDAD",$scope.discapacidad)

                currentPacient.save(null, {
                  success: function(paciente) {
                    alert('New object created with objectId: ' + paciente.id);
                  },
                  error: function(paciente, error) {
                    alert('Failed to create new object, with error code: ' + error.message);
                  }
                });
            }
        }
        $('#pacienteChart').highcharts({
        title: {
            text: 'Combination chart'
        },
        xAxis: {
            categories: ['Apples', 'Oranges', 'Pears', 'Bananas', 'Plums']
        },
        labels: {
            items: [{
                html: 'Total fruit consumption',
                style: {
                    left: '50px',
                    top: '18px',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'black'
                }
            }]
        },
        series: [{
            type: 'column',
            name: 'Jane',
            data: [3, 2, 1, 3, 4]
        }, {
            type: 'column',
            name: 'John',
            data: [2, 3, 5, 7, 6]
        }, {
            type: 'column',
            name: 'Joe',
            data: [4, 3, 3, 9, 0]
        }, {
            type: 'spline',
            name: 'Average',
            data: [3, 2.67, 3, 6.33, 3.33],
            marker: {
                lineWidth: 2,
                lineColor: Highcharts.getOptions().colors[3],
                fillColor: 'white'
            }
        }, {
            type: 'pie',
            name: 'Total consumption',
            data: [{
                name: 'Jane',
                y: 13,
                color: Highcharts.getOptions().colors[0] // Jane's color
            }, {
                name: 'John',
                y: 23,
                color: Highcharts.getOptions().colors[1] // John's color
            }, {
                name: 'Joe',
                y: 19,
                color: Highcharts.getOptions().colors[2] // Joe's color
            }],
            center: [100, 80],
            size: 100,
            showInLegend: false,
            dataLabels: {
                enabled: false
            }
        }]
    });
	}]);
})